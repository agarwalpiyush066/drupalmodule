<?php

namespace Drupal\site_locationtime\CacheContext;

use Drupal\Core\Cache\Context\CacheContextInterface;
use Drupal\Core\Session\AccountProxy;
use Drupal\user\Entity\User;
use Drupal\Core\Cache\CacheableMetadata;
use Drupal\Core\Datetime\DrupalDateTime;

class TimedateSummaryCacheContext implements CacheContextInterface {

  /**
  * {@inheritdoc}
  */
	public function __construct() {

	}

  /**
  * {@inheritdoc}
  */
	public static function getLabel() {
		return t('Location and Date TIme Summary cache context');
	}

  /**
  * {@inheritdoc}
  */
	public function getContext() {
        $config = \Drupal::config('sitelocationtime.adminsettings');
        $date = new DrupalDateTime();
        $date->setTimezone(new \DateTimeZone($config->get('site_time_zone')));
        $summary = $date->format('m/d/Y g:ia');;
        return $summary;
    }

  /**
  * {@inheritdoc}
  */
  public function getCacheableMetadata() {
    return new CacheableMetadata();
  }
}