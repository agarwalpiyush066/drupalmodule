<?php

namespace Drupal\site_locationtime\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Cache\Cache;
use Drupal\user\Entity\User;
use Symfony\Component\DependencyInjection\ContainerInterface;
/**
 * Provides a 'SiteLocationTime' block.
 *
 * @Block(
 *  id = "site_locationtime_block",
 *  admin_label = @Translation("Site Location Time Block"),
 * )
 */
class SiteLocationTImeBlock extends BlockBase {

  public function build() {
    $build = [];
    $config = \Drupal::config('sitelocationtime.adminsettings');
    $data = [];
    $site_country = $config->get('site_country');
    $site_city = $config->get('site_city');
    $site_time_zone = $config->get('site_time_zone');
    $placeholder = 'site_locationtime' . crc32('lazy site_locationtime block');
    $build['#attached']['placeholders'][$placeholder] = [
      '#lazy_builder' => ['site_locationtime.getCurrentTimeDate:getCurrentTimeDate', [$site_time_zone]],
      '#create_placeholder' => TRUE
    ];
    
    $build['timedate_summary'] = [
			'#theme' => 'site_locationtime_block',
      '#variables' => Null,
      '#site_country' => $site_country,
      '#site_city' => $site_city,
      '#site_time_zone' => $site_time_zone,
      '#site_current_timedate' => $placeholder,
		]; 
		return $build;
  }

    /**
   * {@inheritdoc}
   */
  public function getCacheContexts() {
  	return Cache::mergeContexts(
  		parent::getCacheContexts(),
  		['timedate_summary']
  	);
  }

  
}