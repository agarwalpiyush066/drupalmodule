<?php

/**
* @file providing the service that return current date and time on the basis of timezone.
*
*/

namespace  Drupal\site_locationtime;

use Drupal\Core\Cache\Cache;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Datetime\DrupalDateTime;

class CurrentDateTimeServices {

 protected $say_something;
 protected $formatTranslationCache;
 public function __construct() {
   $this->say_something = 'Please provide a valid timezone';
 }

 public function getCurrentTimeDate($timezone = ''){
    // Do NOT cache a page with this block on it.
    \Drupal::service('page_cache_kill_switch')->trigger();
   if (empty($timezone)) {
     return $this->say_something;
   }
   else {
    $date = new DrupalDateTime();
    $date->setTimezone(new \DateTimeZone($timezone));
    return [
      '#markup' => $date->format('jS M Y - g:i A')
    ];
   }
 }

}

?>